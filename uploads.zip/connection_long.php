<?php
// define("db_host", "localhost");
// define("db_user", "u680385054_procurement");
// define("db_pass", "@Mk5^vnVJ");
// define("db_name", "u680385054_pro");

define("db_host", "localhost");
define("db_user", "root");
define("db_pass", "");
define("db_name", "pam");
?>