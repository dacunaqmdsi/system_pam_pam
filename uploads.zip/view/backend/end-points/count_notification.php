<?php
include('../class.php');
    $db = new global_class();

    

    $report = $db->count_notification();
   