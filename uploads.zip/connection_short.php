<?php
// $db_connection = mysqli_connect("localhost", "u680385054_procurement", "@Mk5^vnVJ", "u680385054_pro");
$db_connection = mysqli_connect("localhost", "root", "", "pam");
$conn = mysqli_connect("localhost", "root", "", "pam");
?>