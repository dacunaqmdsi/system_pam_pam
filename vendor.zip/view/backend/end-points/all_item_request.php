<?php
include('../class.php');
$db = new global_class();



$orders = $db->all_item_request();

    
   