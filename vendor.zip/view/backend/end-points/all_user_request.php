<?php
include('../class.php');
$db = new global_class();



$orders = $db->all_user_request();

    
   